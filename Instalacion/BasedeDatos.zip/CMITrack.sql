CREATE LOGIN CMITrackUser WITH PASSWORD = 'Us3RCmi7rAck';
GO
CREATE DATABASE CMITrack;
GO
USE CMITrack
GO
CREATE USER CMITrackUser FROM LOGIN CMITrackUser;
GO
EXEC sp_addrolemember 'db_owner', 'CMITrackUser';
GO

